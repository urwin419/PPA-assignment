import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.scene.text.Text;
import javafx.scene.layout.VBox;
import javafx.scene.control.ComboBox;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.ArrayList;

import javafx.scene.layout.GridPane;
import javafx.scene.Group;
import javafx.scene.text.Font;
import javafx.scene.paint.Color;
/**
 * Write a description of JavaFX class window here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
//public class newWindow extends Application
//{
//}
   